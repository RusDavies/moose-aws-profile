using System;
using System.Windows.Forms;
using System.IO;

namespace CS_AddinTaggedCSV
{
	public class Main
	{
		public string filecontents = "";
		public bool readline = false;
		private bool m_ShowFullMenus = false;
		public Form1 theForm;

		//Called Before EA starts to check Add-In Exists
		public String EA_Connect(EA.Repository Repository)
		{
			//No special processing required.
			return "a string";
		}

		//Called when user Click Add-Ins Menu item from within EA.
		//Populates the Menu with our desired selections.
		public object EA_GetMenuItems(EA.Repository Repository, string Location, string MenuName) 
		{
			EA.Package aPackage = Repository.GetTreeSelectedPackage();
			switch( MenuName )
			{
				case "":
					return "-&CS AddinTaggedCSV";
				case "-&CS AddinTaggedCSV":
					string[] ar = { "&Tagged CSV Export", "", "About..." };
					return ar;
			}
			return "";
		}
		
		//Sets the state of the menu depending if there is an active project or not
		bool IsProjectOpen(EA.Repository Repository)
		{
			try
			{
				EA.Collection c = Repository.Models;
				return true;
			}
			catch
			{
				return false;
			}
		}

		//Called once Menu has been opened to see what menu items are active.
		public void EA_GetMenuState(EA.Repository Repository, string Location, string MenuName, string ItemName, ref bool IsEnabled, ref bool IsChecked)
		{
			if( IsProjectOpen(Repository) )
			{
				if( ItemName == "&Tagged CSV Export" )
					IsChecked = m_ShowFullMenus;
				else if( ItemName == "Menu2")
					IsEnabled = m_ShowFullMenus;
			}
			else
				// If no open project, disable all menu options
				IsEnabled = false;
		}

		//Called when user makes a selection in the menu.
		//This is your main exit point to the rest of your Add-in
		public void EA_MenuClick(EA.Repository Repository, string Location, string MenuName, string ItemName)
		{						
			switch( ItemName )
			{
				case "&Tagged CSV Export":	

					String writerString;
					String tagString;

					tagString = "";
					writerString = "";

					EA.Package aPackage;
					aPackage = Repository.GetTreeSelectedPackage();

					foreach(EA.Package thePackage in aPackage.Packages)
					{
						writerString = writerString + thePackage.Name.ToString() + "," + thePackage.ObjectType.ToString() + "\n";
						//MessageBox.Show(writerString);
						foreach(EA.Element theElements in thePackage.Elements)
						{
							foreach(EA.TaggedValue theTags in theElements.TaggedValues)
							{	
								tagString = tagString + theTags.Name.ToString() + "," + theTags.Value.ToString() + ",";
							}
							writerString = writerString + theElements.Name.ToString() + "," + theElements.ObjectType.ToString() + "," + tagString + "\n";
							tagString = "";
						}
					}

					foreach(EA.Element theElements in aPackage.Elements)
					{
						foreach(EA.TaggedValue theTags in theElements.TaggedValues)
						{	
							tagString = tagString + theTags.Name.ToString() + "," + theTags.Value.ToString() + ",";
						}
						writerString = writerString + theElements.Name.ToString() + "," + theElements.ObjectType.ToString() + "," + tagString;
						tagString = "";
					}

					
					// create a writer and open the file
					TextWriter tw = new StreamWriter(aPackage.Name.ToString() + ".csv");

					// write a line of text to the file
					tw.WriteLine(writerString);

					// close the stream
					tw.Close();

					break;					
				case "&Menu2":	


					
					break;
				case "About...":
					Form1 anAbout = new Form1();
					anAbout.ShowDialog();					
					break;
			}
		}
		public bool readLine(StreamReader sreader)
		{
			bool answer;
			answer = false;
			
			try
			{
				filecontents = filecontents + "\n" + sreader.ReadLine();
			}
			catch
			{
				answer = true;
			}

			return answer;
		}
	}
}
		
		
	

